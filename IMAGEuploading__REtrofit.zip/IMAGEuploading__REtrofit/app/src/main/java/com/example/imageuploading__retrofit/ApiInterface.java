package com.example.imageuploading__retrofit;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ApiInterface {
/*
    @Multipart
    @POST("uploadimages.php")
    Call<ResponsePOJO> uploadImage(@Part MultipartBody.Part image);

*/
    @POST("uploadi.php")
    @FormUrlEncoded
    Call<ResponsePOJO> uploadIm(@Field("name") String name,@Field("image") String image);

}